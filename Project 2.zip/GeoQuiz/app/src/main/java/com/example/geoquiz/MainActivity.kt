package com.example.geoquiz

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.example.geoquiz.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar


private const val TAG = "MainActivity"

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val quizViewModel: QuizViewModel by viewModels()

    private val cheatLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        //Handle Result
        if (result.resultCode == Activity.RESULT_OK) {
            quizViewModel.setCheat()
            quizViewModel.isCheater =
                result.data?.getBooleanExtra(EXTRA_ANSWER_SHOWN, false) ?: false
        }
    }

    private var numCorrect = 0.0
    private var numGuess = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "onCreate(Bundle?) called")
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Log.d(TAG, "Got aQuizViewModel: $quizViewModel")

        Toast.makeText(
            this,
            R.string.welcome_message,
            Toast.LENGTH_SHORT
        ).show()

        binding.trueButton.setOnClickListener { view: View ->
            checkAnswer(true)
            quizViewModel.answerQuestion()
            isAnswered(quizViewModel.currentIndex)

            quizViewModel.currentQuestionIsAnswered = true
        }

        binding.falseButton.setOnClickListener { view: View ->
            checkAnswer(false)
            quizViewModel.answerQuestion()
            isAnswered(quizViewModel.currentIndex)

            quizViewModel.currentQuestionIsAnswered = true
        }

        binding.nextButton.setOnClickListener {
            quizViewModel.moveToNext()
            isAnswered(quizViewModel.currentIndex)
            updateQuestion()
        }

        binding.prevButton.setOnClickListener {
            quizViewModel.moveToPrev()
            isAnswered(quizViewModel.currentIndex)
            updateQuestion()
        }

        binding.cheatButton.setOnClickListener {
            val answerIsTrue = quizViewModel.currentQuestionAnswer
            val intent = CheatActivity.newIntent(this@MainActivity, answerIsTrue )
            cheatLauncher.launch(intent)
        }

        binding.questionTextView.setOnClickListener {
            quizViewModel.moveToNext()
            updateQuestion()
        }

        updateQuestion()
    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "onStart(Bundle?) called")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume(Bundle?) called")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "onPause(Bundle?) called")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "onStop(Bundle?) called")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy(Bundle?) called")
    }

    private fun updateQuestion() {
        val questionTextResId = quizViewModel.currentQuestionText
        binding.questionTextView.setText((questionTextResId))
    }

    private fun checkAnswer(userAnswer: Boolean) {
        val correctAnswer = quizViewModel.currentQuestionAnswer
        numGuess += 1

        val messageResId = when {
            quizViewModel.isCheater -> R.string.judgment_toast
            userAnswer == correctAnswer -> R.string.correct_answer_msg
            else -> R.string.incorrect_answer_msg
        }
        Snackbar.make(findViewById(R.id.root), messageResId, Snackbar.LENGTH_SHORT)
            .show()


        if (userAnswer == correctAnswer) {
            numCorrect += 1.0
        }
//
//        if (quizViewModel.isCheater) {
//            numCorrect -= 1.0
//        } //Cheaters never prosper
//
        val finalScore = "Your final score is: " + (numCorrect * 100.0)/quizViewModel.size + "%."

        if (numGuess == quizViewModel.size) {
            Toast.makeText(this, finalScore, Toast.LENGTH_SHORT)
                .show()




//
//    if (quizViewModel.questionBank.any{ Question -> Question.isCheater == true }
//    ) {
//        val finalCheatScore = "Your final score is: " + (numCorrect * 100.0)/quizViewModel.size + "%. Cheating is still wrong. Minus 10 points from Gryffindor"
//        Toast.makeText(this, finalCheatScore, Toast.LENGTH_SHORT)
//            .show()
//    } else {
//        Toast.makeText(this, finalScore, Toast.LENGTH_SHORT)
//            .show()
//
//    }




        }
    }

    private fun isAnswered(index: Int) {
        if (quizViewModel.currentQuestionIsAnswered == true) {
            binding.trueButton.isClickable = false
            binding.falseButton.isClickable = false
        } else {
            binding.trueButton.isClickable = true
            binding.falseButton.isClickable = true
        }
    }
}