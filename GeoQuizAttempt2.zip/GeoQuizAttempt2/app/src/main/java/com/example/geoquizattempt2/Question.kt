package com.example.geoquizattempt2

import androidx.annotation.StringRes

data class Question(@StringRes val questionTextResId: Int, val questionAnswer:Boolean)
