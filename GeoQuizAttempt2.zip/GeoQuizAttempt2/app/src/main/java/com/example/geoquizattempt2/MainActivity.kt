package com.example.geoquizattempt2

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.geoquizattempt2.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    private val questionBank = listOf(
        Question(R.string.question_australia, true),
        Question(R.string.question_oceans, true),
        Question(R.string.question_mideast, false),
        Question(R.string.question_africa, false),
        Question(R.string.question_americas, true),
        Question(R.string.question_asia, true))

    private var currentIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        Toast.makeText(
            this,
            "Welcome to GeoQuiz!",
            Toast.LENGTH_SHORT
        ).show()

        binding.trueButton.setOnClickListener {
           checkAnswer(true)
        }

        binding.falseButton.setOnClickListener{
            checkAnswer(false)
        }

        updateQuestion()

        binding.nextButton.setOnClickListener {
            nextQuestion()
        }

        binding.prevButton.setOnClickListener {
            nextQuestion()
        }

        binding.questionTextView.setOnClickListener {
            currentIndex = (currentIndex - 1 + questionBank.size) % questionBank.size
            updateQuestion()
        }
    }

    private fun nextQuestion(){
        currentIndex = (currentIndex+1) % questionBank.size
        updateQuestion()
    }

    private fun updateQuestion(){
        val questionTextResId = questionBank[currentIndex].questionTextResId
        binding.questionTextView.setText(questionTextResId)
    }

    private fun checkAnswer(userAnswer: Boolean){
        val correctAnswer = questionBank[currentIndex].questionAnswer
        val answerTextResId = when(userAnswer){
            correctAnswer   -> R.string.correct_answer_msg
            else            -> R.string.incorrect_answer_msg
        }
        Snackbar.make(
            binding.root,
            answerTextResId,
            Snackbar.LENGTH_SHORT
        ).show()
    }
}